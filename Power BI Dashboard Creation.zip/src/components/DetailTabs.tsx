import { useState } from 'react';
import { Search, Download, Filter } from 'lucide-react';

interface DetailTabsProps {
  filters: any;
}

export function DetailTabs({ filters }: DetailTabsProps) {
  const [activeDetailTab, setActiveDetailTab] = useState('parts');
  const [searchTerm, setSearchTerm] = useState('');

  // Part-Level Detail Data
  const partDetails = [
    {
      partNumber: 'MEM-DDR5-4800-16GB',
      supplier: 'SK Hynix',
      spend: 45.2,
      costTrend: 'up',
      moq: 5000,
      leadTime: 42,
      strategicScore: 92,
      alternatives: 'Samsung, Micron',
      savings: 3.8
    },
    {
      partNumber: 'LCD-15.6-FHD-IPS',
      supplier: 'Samsung Display',
      spend: 38.6,
      costTrend: 'down',
      moq: 2000,
      leadTime: 38,
      strategicScore: 85,
      alternatives: 'BOE, LG Display',
      savings: 2.4
    },
    {
      partNumber: 'CPU-I7-13700H',
      supplier: 'Intel',
      spend: 52.3,
      costTrend: 'stable',
      moq: 1000,
      leadTime: 56,
      strategicScore: 98,
      alternatives: 'AMD (Ryzen 7000)',
      savings: 4.2
    },
    {
      partNumber: 'PCB-MB-6LAYER',
      supplier: 'Unimicron',
      spend: 28.4,
      costTrend: 'up',
      moq: 3000,
      leadTime: 35,
      strategicScore: 72,
      alternatives: 'Compeq, Tripod',
      savings: 1.8
    },
    {
      partNumber: 'BAT-LI-56WH',
      supplier: 'Simplo',
      spend: 22.1,
      costTrend: 'stable',
      moq: 5000,
      leadTime: 28,
      strategicScore: 78,
      alternatives: 'Celxpert, Dynapack',
      savings: 1.2
    }
  ];

  // Contract Analytics Data
  const contracts = [
    {
      supplier: 'Foxconn',
      category: 'ODM Services',
      expiry: '2025-03-31',
      value: 580,
      escalation: 'CPI + 2%',
      indexation: 'US CPI',
      rebateEarned: 8.2,
      rebateMissed: 1.4,
      status: 'expiring'
    },
    {
      supplier: 'SK Hynix',
      category: 'Memory',
      expiry: '2025-06-30',
      value: 340,
      escalation: 'DRAM Spot -5%',
      indexation: 'DRAMeXchange',
      rebateEarned: 5.8,
      rebateMissed: 0.3,
      status: 'active'
    },
    {
      supplier: 'Samsung',
      category: 'Displays',
      expiry: '2024-12-31',
      value: 380,
      escalation: 'Fixed 3 years',
      indexation: 'None',
      rebateEarned: 6.5,
      rebateMissed: 0.8,
      status: 'expiring'
    },
    {
      supplier: 'Pegatron',
      category: 'ODM Services',
      expiry: '2026-01-15',
      value: 420,
      escalation: 'Labor index + 1.5%',
      indexation: 'Taiwan Labor',
      rebateEarned: 7.2,
      rebateMissed: 0.5,
      status: 'active'
    }
  ];

  // Commodity Risk Data
  const commodityRisk = [
    {
      commodity: 'DRAM',
      currentIndex: 4.85,
      trend: 'up',
      correlation: 0.92,
      hpCost: 680,
      costChange: '+12%',
      hedging: 'None',
      recommendation: 'Consider long-term contract'
    },
    {
      commodity: 'Copper',
      currentIndex: 8420,
      trend: 'stable',
      correlation: 0.76,
      hpCost: 85,
      costChange: '+2%',
      hedging: 'Partial',
      recommendation: 'Monitor geopolitical risk'
    },
    {
      commodity: 'Plastics (PP)',
      currentIndex: 1.12,
      trend: 'down',
      correlation: 0.88,
      hpCost: 180,
      costChange: '-5%',
      hedging: 'None',
      recommendation: 'Lock pricing short-term'
    },
    {
      commodity: 'LCD Panels',
      currentIndex: 94.2,
      trend: 'down',
      correlation: 0.94,
      hpCost: 520,
      costChange: '-8%',
      hedging: 'None',
      recommendation: 'Negotiate floor pricing'
    }
  ];

  const getTrendIcon = (trend: string) => {
    if (trend === 'up') return '↑';
    if (trend === 'down') return '↓';
    return '→';
  };

  const getTrendColor = (trend: string) => {
    if (trend === 'up') return 'text-red-600';
    if (trend === 'down') return 'text-green-600';
    return 'text-slate-600';
  };

  const getStatusBadge = (status: string) => {
    if (status === 'expiring') {
      return <span className="px-2 py-1 bg-amber-100 text-amber-700 rounded text-xs">Expiring Soon</span>;
    }
    return <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">Active</span>;
  };

  return (
    <div className="space-y-6">
      {/* Sub-Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200">
        <div className="flex border-b border-slate-200">
          <button
            onClick={() => setActiveDetailTab('parts')}
            className={`px-6 py-4 transition-colors ${
              activeDetailTab === 'parts'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Part-Level Details
          </button>
          <button
            onClick={() => setActiveDetailTab('contracts')}
            className={`px-6 py-4 transition-colors ${
              activeDetailTab === 'contracts'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Contract Analytics
          </button>
          <button
            onClick={() => setActiveDetailTab('commodity')}
            className={`px-6 py-4 transition-colors ${
              activeDetailTab === 'commodity'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Commodity Risk
          </button>
        </div>

        {/* Search and Actions */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder={`Search ${activeDetailTab}...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-lg hover:bg-slate-50">
            <Filter className="w-4 h-4" />
            Advanced Filters
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>

        {/* Part-Level Details */}
        {activeDetailTab === 'parts' && (
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left">Part Number</th>
                    <th className="px-4 py-3 text-left">Supplier</th>
                    <th className="px-4 py-3 text-right">Annual Spend ($M)</th>
                    <th className="px-4 py-3 text-center">Cost Trend</th>
                    <th className="px-4 py-3 text-right">MOQ</th>
                    <th className="px-4 py-3 text-right">Lead Time (days)</th>
                    <th className="px-4 py-3 text-center">Strategic Score</th>
                    <th className="px-4 py-3 text-left">Alternative Suppliers</th>
                    <th className="px-4 py-3 text-right">Savings Potential ($M)</th>
                  </tr>
                </thead>
                <tbody>
                  {partDetails.map((part, index) => (
                    <tr key={index} className="border-t border-slate-200 hover:bg-slate-50">
                      <td className="px-4 py-3 font-mono text-xs">{part.partNumber}</td>
                      <td className="px-4 py-3">{part.supplier}</td>
                      <td className="px-4 py-3 text-right">${part.spend}M</td>
                      <td className={`px-4 py-3 text-center ${getTrendColor(part.costTrend)}`}>
                        {getTrendIcon(part.costTrend)}
                      </td>
                      <td className="px-4 py-3 text-right">{part.moq.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right">{part.leadTime}</td>
                      <td className="px-4 py-3 text-center">
                        <div
                          className={`inline-flex items-center justify-center w-12 h-6 rounded ${
                            part.strategicScore >= 90
                              ? 'bg-green-100 text-green-700'
                              : part.strategicScore >= 75
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-amber-100 text-amber-700'
                          }`}
                        >
                          {part.strategicScore}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs">{part.alternatives}</td>
                      <td className="px-4 py-3 text-right text-green-600">${part.savings}M</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-4 flex items-center justify-between text-sm text-slate-600">
              <span>Showing 5 of 1,248 parts</span>
              <div className="flex gap-2">
                <button className="px-3 py-1 border border-slate-300 rounded hover:bg-slate-50">Previous</button>
                <button className="px-3 py-1 border border-slate-300 rounded hover:bg-slate-50">Next</button>
              </div>
            </div>
          </div>
        )}

        {/* Contract Analytics */}
        {activeDetailTab === 'contracts' && (
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left">Supplier</th>
                    <th className="px-4 py-3 text-left">Category</th>
                    <th className="px-4 py-3 text-left">Expiry Date</th>
                    <th className="px-4 py-3 text-right">Contract Value ($M)</th>
                    <th className="px-4 py-3 text-left">Escalation Clause</th>
                    <th className="px-4 py-3 text-left">Index</th>
                    <th className="px-4 py-3 text-right">Rebate Earned ($M)</th>
                    <th className="px-4 py-3 text-right">Rebate Missed ($M)</th>
                    <th className="px-4 py-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {contracts.map((contract, index) => (
                    <tr key={index} className="border-t border-slate-200 hover:bg-slate-50">
                      <td className="px-4 py-3">{contract.supplier}</td>
                      <td className="px-4 py-3">{contract.category}</td>
                      <td className="px-4 py-3">{contract.expiry}</td>
                      <td className="px-4 py-3 text-right">${contract.value}M</td>
                      <td className="px-4 py-3">{contract.escalation}</td>
                      <td className="px-4 py-3">{contract.indexation}</td>
                      <td className="px-4 py-3 text-right text-green-600">${contract.rebateEarned}M</td>
                      <td className="px-4 py-3 text-right text-red-600">${contract.rebateMissed}M</td>
                      <td className="px-4 py-3 text-center">{getStatusBadge(contract.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm">
                <span className="font-medium">Action Required:</span> 2 contracts expiring within 120 days. Initiate
                renegotiation with Foxconn and Samsung. Estimated savings opportunity: $28M through revised pricing
                structures.
              </p>
            </div>
          </div>
        )}

        {/* Commodity Risk */}
        {activeDetailTab === 'commodity' && (
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left">Commodity</th>
                    <th className="px-4 py-3 text-right">Market Index</th>
                    <th className="px-4 py-3 text-center">Trend</th>
                    <th className="px-4 py-3 text-right">Correlation</th>
                    <th className="px-4 py-3 text-right">HP Cost Impact ($M)</th>
                    <th className="px-4 py-3 text-center">YTD Change</th>
                    <th className="px-4 py-3 text-center">Hedging</th>
                    <th className="px-4 py-3 text-left">Recommendation</th>
                  </tr>
                </thead>
                <tbody>
                  {commodityRisk.map((item, index) => (
                    <tr key={index} className="border-t border-slate-200 hover:bg-slate-50">
                      <td className="px-4 py-3">{item.commodity}</td>
                      <td className="px-4 py-3 text-right">{item.currentIndex}</td>
                      <td className={`px-4 py-3 text-center ${getTrendColor(item.trend)}`}>
                        {getTrendIcon(item.trend)}
                      </td>
                      <td className="px-4 py-3 text-right">{item.correlation}</td>
                      <td className="px-4 py-3 text-right">${item.hpCost}M</td>
                      <td className={`px-4 py-3 text-center ${getTrendColor(item.trend)}`}>{item.costChange}</td>
                      <td className="px-4 py-3 text-center">
                        {item.hedging === 'None' ? (
                          <span className="text-amber-600">None</span>
                        ) : (
                          <span className="text-green-600">{item.hedging}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs">{item.recommendation}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-6 grid grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="text-sm mb-2">High Correlation Alert</h4>
                <p className="text-xs text-slate-600">
                  DRAM and LCD Panel costs show 92%+ correlation to market indices. Consider volume commitments or
                  hedging strategies to lock favorable pricing.
                </p>
              </div>
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="text-sm mb-2">Opportunity</h4>
                <p className="text-xs text-slate-600">
                  Plastics pricing down 5% YTD. Lock short-term contracts (6-12 months) to capture savings before
                  potential oil price recovery.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
