import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, Treemap, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, AlertCircle, DollarSign } from 'lucide-react';

interface SpendAnalyticsProps {
  filters: any;
}

export function SpendAnalytics({ filters }: SpendAnalyticsProps) {
  // Spend by Category (Treemap)
  const categoryData = [
    { name: 'Components', value: 820, color: '#3b82f6' },
    { name: 'Memory', value: 680, color: '#06b6d4' },
    { name: 'Displays', value: 520, color: '#8b5cf6' },
    { name: 'Semiconductors', value: 450, color: '#10b981' },
    { name: 'Plastics', value: 180, color: '#f59e0b' },
    { name: 'Metals', value: 150, color: '#ef4444' }
  ];

  // Spend by Supplier
  const supplierData = [
    { name: 'Foxconn', spend: 580, concentration: 20.7 },
    { name: 'Pegatron', spend: 420, concentration: 15.0 },
    { name: 'Samsung', spend: 380, concentration: 13.6 },
    { name: 'SK Hynix', spend: 340, concentration: 12.1 },
    { name: 'Quanta', spend: 280, concentration: 10.0 },
    { name: 'TSMC', spend: 260, concentration: 9.3 },
    { name: 'Compal', spend: 220, concentration: 7.9 },
    { name: 'Others', spend: 320, concentration: 11.4 }
  ];

  // Spend by Region
  const regionData = [
    { name: 'APAC', value: 1680, percentage: 60 },
    { name: 'North America', value: 560, percentage: 20 },
    { name: 'Europe', value: 392, percentage: 14 },
    { name: 'LATAM', value: 168, percentage: 6 }
  ];

  // Spend Trend (24 months)
  const trendData = [
    { month: 'Jan 23', spend: 108, budget: 115 },
    { month: 'Feb 23', spend: 112, budget: 115 },
    { month: 'Mar 23', spend: 118, budget: 115 },
    { month: 'Apr 23', spend: 115, budget: 115 },
    { month: 'May 23', spend: 120, budget: 120 },
    { month: 'Jun 23', spend: 125, budget: 120 },
    { month: 'Jul 23', spend: 122, budget: 120 },
    { month: 'Aug 23', spend: 128, budget: 125 },
    { month: 'Sep 23', spend: 132, budget: 125 },
    { month: 'Oct 23', spend: 135, budget: 130 },
    { month: 'Nov 23', spend: 130, budget: 130 },
    { month: 'Dec 23', spend: 138, budget: 130 },
    { month: 'Jan 24', spend: 115, budget: 120 },
    { month: 'Feb 24', spend: 118, budget: 120 },
    { month: 'Mar 24', spend: 122, budget: 120 },
    { month: 'Apr 24', spend: 119, budget: 120 },
    { month: 'May 24', spend: 125, budget: 125 },
    { month: 'Jun 24', spend: 128, budget: 125 },
    { month: 'Jul 24', spend: 130, budget: 125 },
    { month: 'Aug 24', spend: 126, budget: 125 },
    { month: 'Sep 24', spend: 132, budget: 130 },
    { month: 'Oct 24', spend: 135, budget: 130 },
    { month: 'Nov 24', spend: 133, budget: 130 },
    { month: 'Dec 24', spend: 140, budget: 135 }
  ];

  // Strategic vs Non-Strategic
  const strategicData = [
    { name: 'Strategic', value: 2240, percentage: 80 },
    { name: 'Non-Strategic', value: 560, percentage: 20 }
  ];

  const COLORS = ['#3b82f6', '#06b6d4', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444'];

  const insights = [
    {
      icon: AlertCircle,
      color: 'red',
      title: 'High Supplier Concentration',
      description: 'Top 3 suppliers account for 49.3% of total spend - diversification recommended'
    },
    {
      icon: TrendingUp,
      color: 'amber',
      title: 'Memory Costs Rising',
      description: 'Memory category spend up 12% vs. budget due to DRAM market conditions'
    },
    {
      icon: DollarSign,
      color: 'green',
      title: 'Renegotiation Opportunity',
      description: '$45M savings potential identified across 8 suppliers with expiring contracts'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Insights Panel */}
      <div className="grid grid-cols-3 gap-4">
        {insights.map((insight, index) => {
          const Icon = insight.icon;
          return (
            <div key={index} className="bg-white p-5 rounded-lg shadow-sm border border-slate-200">
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-lg bg-${insight.color}-100`}>
                  <Icon className={`w-5 h-5 text-${insight.color}-600`} />
                </div>
                <div className="flex-1">
                  <h3 className="text-sm mb-1">{insight.title}</h3>
                  <p className="text-sm text-slate-600">{insight.description}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Charts Grid */}
      <div className="grid grid-cols-2 gap-6">
        {/* Spend by Category - Treemap */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="mb-4">Spend by Category</h3>
          <ResponsiveContainer width="100%" height={300}>
            <Treemap
              data={categoryData}
              dataKey="value"
              aspectRatio={4 / 3}
              stroke="#fff"
              content={({ x, y, width, height, name, value, color }) => {
                if (width < 50 || height < 50) return null;
                return (
                  <g>
                    <rect
                      x={x}
                      y={y}
                      width={width}
                      height={height}
                      style={{ fill: color, stroke: '#fff', strokeWidth: 2 }}
                    />
                    <text x={x + width / 2} y={y + height / 2 - 8} textAnchor="middle" fill="#fff">
                      {name}
                    </text>
                    <text x={x + width / 2} y={y + height / 2 + 12} textAnchor="middle" fill="#fff">
                      ${value}M
                    </text>
                  </g>
                );
              }}
            />
          </ResponsiveContainer>
        </div>

        {/* Spend by Supplier */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="mb-4">Spend by Supplier (Concentration Risk)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={supplierData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="name" type="category" width={80} />
              <Tooltip />
              <Bar dataKey="spend" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Spend Trend */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 col-span-2">
          <h3 className="mb-4">24-Month Spend Trend vs. Budget</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="spend" stroke="#3b82f6" strokeWidth={2} name="Actual Spend ($M)" />
              <Line type="monotone" dataKey="budget" stroke="#94a3b8" strokeWidth={2} strokeDasharray="5 5" name="Budget ($M)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Spend by Region */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="mb-4">Spend by Region</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={regionData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percentage }) => `${name} ${percentage}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {regionData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Strategic vs Non-Strategic */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="mb-4">Strategic vs Non-Strategic Spend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={strategicData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percentage }) => `${name} ${percentage}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
                innerRadius={60}
              >
                <Cell fill="#3b82f6" />
                <Cell fill="#94a3b8" />
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Strategic Spend:</span>
              <span>$2,240M</span>
            </div>
            <div className="flex justify-between text-sm text-slate-600">
              <span>Non-Strategic Spend:</span>
              <span>$560M</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
