import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, Cell } from 'recharts';
import { MapPin, TrendingUp, DollarSign, Clock } from 'lucide-react';

interface ReshoringStrategyProps {
  filters: any;
}

export function ReshoringStrategy({ filters }: ReshoringStrategyProps) {
  // Single vs Multi-sourced Parts
  const sourcingData = [
    { category: 'Memory', single: 45, multi: 55, total: 100 },
    { category: 'Displays', single: 62, multi: 38, total: 100 },
    { category: 'Processors', single: 78, multi: 22, total: 100 },
    { category: 'Components', single: 35, multi: 65, total: 100 },
    { category: 'Plastics', single: 28, multi: 72, total: 100 },
    { category: 'PCBs', single: 42, multi: 58, total: 100 }
  ];

  // Regional Dependency Data
  const dependencyData = [
    { region: 'China', spend: 980, risk: 72, parts: 1250 },
    { region: 'Taiwan', spend: 520, risk: 58, parts: 680 },
    { region: 'Vietnam', spend: 340, risk: 42, parts: 520 },
    { region: 'Malaysia', spend: 280, risk: 38, parts: 380 },
    { region: 'South Korea', spend: 420, risk: 28, parts: 420 },
    { region: 'Mexico', spend: 140, risk: 22, parts: 240 },
    { region: 'Europe', spend: 220, risk: 18, parts: 320 }
  ];

  // Reshoring Cost Impact Scenarios
  const scenarioData = [
    { scenario: 'Base (Current)', cost: 2800, leadTime: 45, risk: 65 },
    { scenario: 'China+1 (Diversify)', cost: 2912, leadTime: 42, risk: 48 },
    { scenario: 'Nearshore Mexico', cost: 3080, leadTime: 28, risk: 32 },
    { scenario: 'Nearshore EU', cost: 3220, leadTime: 25, risk: 28 },
    { scenario: 'Dual Source', cost: 2940, leadTime: 38, risk: 42 }
  ];

  // KPI Cards
  const kpis = [
    {
      icon: MapPin,
      label: 'Multi-sourced %',
      value: '52%',
      target: '>60%',
      status: 'warning'
    },
    {
      icon: TrendingUp,
      label: 'High-Risk Region Dependency',
      value: '35%',
      target: '<25%',
      status: 'critical'
    },
    {
      icon: DollarSign,
      label: 'Resiliency Cost Premium',
      value: '+4.2%',
      target: '<5%',
      status: 'good'
    },
    {
      icon: Clock,
      label: 'Avg Lead Time Reduction',
      value: '-7 days',
      target: '-10 days',
      status: 'good'
    }
  ];

  const getRiskColor = (risk: number) => {
    if (risk > 60) return '#ef4444';
    if (risk > 40) return '#f59e0b';
    return '#10b981';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good':
        return 'border-green-500 bg-green-50';
      case 'warning':
        return 'border-amber-500 bg-amber-50';
      case 'critical':
        return 'border-red-500 bg-red-50';
      default:
        return 'border-slate-300 bg-slate-50';
    }
  };

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4">
        {kpis.map((kpi, index) => {
          const Icon = kpi.icon;
          return (
            <div key={index} className={`p-5 rounded-lg border-l-4 shadow-sm ${getStatusColor(kpi.status)}`}>
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 rounded-lg bg-blue-100">
                  <Icon className="w-5 h-5 text-blue-600" />
                </div>
                <div className="text-2xl">{kpi.value}</div>
              </div>
              <div className="text-sm mb-1">{kpi.label}</div>
              <div className="text-xs text-slate-600">Target: {kpi.target}</div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Single vs Multi-sourced Parts */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="mb-4">Single vs Multi-sourced Parts by Category</h3>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={sourcingData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="category" />
              <YAxis label={{ value: 'Percentage (%)', angle: -90, position: 'insideLeft' }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="single" stackId="a" fill="#ef4444" name="Single Source" />
              <Bar dataKey="multi" stackId="a" fill="#10b981" name="Multi Source" />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start gap-2">
              <TrendingUp className="w-5 h-5 text-amber-600 mt-0.5" />
              <div>
                <div className="text-sm mb-1">Action Required</div>
                <div className="text-xs text-slate-600">
                  Processors category has 78% single-sourced parts - high continuity risk. Recommend qualifying 2nd source.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Regional Dependency Heatmap */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="mb-4">Regional Dependency (Spend & Risk)</h3>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={dependencyData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="region" type="category" width={100} />
              <Tooltip />
              <Bar dataKey="spend" name="Spend ($M)">
                {dependencyData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getRiskColor(entry.risk)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded" />
                <span>High Risk (&gt;60)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-amber-500 rounded" />
                <span>Medium Risk (40-60)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded" />
                <span>Low Risk (&lt;40)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Reshoring Cost Impact Scenarios */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h3 className="mb-4">Reshoring / Multi-sourcing Cost Impact Analysis</h3>
        <div className="grid grid-cols-3 gap-6">
          <div>
            <h4 className="text-sm text-slate-600 mb-3">Total Cost Impact</h4>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={scenarioData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="scenario" angle={-20} textAnchor="end" height={100} interval={0} />
                <YAxis domain={[2700, 3300]} />
                <Tooltip />
                <Bar dataKey="cost" fill="#3b82f6" name="Cost ($M)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div>
            <h4 className="text-sm text-slate-600 mb-3">Lead Time Reduction</h4>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={scenarioData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="scenario" angle={-20} textAnchor="end" height={100} interval={0} />
                <YAxis domain={[20, 50]} />
                <Tooltip />
                <Line type="monotone" dataKey="leadTime" stroke="#10b981" strokeWidth={2} name="Lead Time (days)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div>
            <h4 className="text-sm text-slate-600 mb-3">Risk Score Reduction</h4>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={scenarioData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="scenario" angle={-20} textAnchor="end" height={100} interval={0} />
                <YAxis domain={[20, 70]} />
                <Tooltip />
                <Line type="monotone" dataKey="risk" stroke="#ef4444" strokeWidth={2} name="Risk Score" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Scenario Comparison Table */}
        <div className="mt-6">
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-left">Scenario</th>
                <th className="px-4 py-3 text-right">Total Cost</th>
                <th className="px-4 py-3 text-right">Cost Δ</th>
                <th className="px-4 py-3 text-right">Lead Time</th>
                <th className="px-4 py-3 text-right">Risk Score</th>
                <th className="px-4 py-3 text-right">Risk Reduction</th>
                <th className="px-4 py-3 text-left">Recommendation</th>
              </tr>
            </thead>
            <tbody>
              {scenarioData.map((scenario, index) => {
                const costDelta = scenario.cost - scenarioData[0].cost;
                const riskReduction = scenarioData[0].risk - scenario.risk;
                return (
                  <tr key={index} className="border-t border-slate-200">
                    <td className="px-4 py-3">{scenario.scenario}</td>
                    <td className="px-4 py-3 text-right">${scenario.cost}M</td>
                    <td className={`px-4 py-3 text-right ${costDelta > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      {costDelta > 0 ? '+' : ''}
                      {costDelta}M
                    </td>
                    <td className="px-4 py-3 text-right">{scenario.leadTime} days</td>
                    <td className="px-4 py-3 text-right">{scenario.risk}</td>
                    <td className={`px-4 py-3 text-right ${riskReduction > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {riskReduction > 0 ? '-' : ''}
                      {Math.abs(riskReduction)} pts
                    </td>
                    <td className="px-4 py-3">
                      {index === 0 && <span className="text-slate-600">Baseline</span>}
                      {index === 1 && (
                        <span className="text-green-600">Recommended: Best risk/cost balance</span>
                      )}
                      {index === 2 && <span className="text-blue-600">High premium, fast delivery</span>}
                      {index === 3 && <span className="text-purple-600">Highest cost, lowest risk</span>}
                      {index === 4 && <span className="text-cyan-600">Moderate improvement</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}