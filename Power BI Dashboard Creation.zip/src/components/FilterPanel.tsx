import { Filter } from 'lucide-react';

interface FilterPanelProps {
  filters: any;
  setFilters: (filters: any) => void;
}

export function FilterPanel({ filters, setFilters }: FilterPanelProps) {
  const filterOptions = {
    supplier: ['All', 'Foxconn', 'Pegatron', 'Quanta', 'Compal', 'Wistron', 'Samsung', 'SK Hynix', 'TSMC'],
    category: ['All', 'Components', 'Memory', 'Displays', 'Semiconductors', 'Plastics', 'Metals', 'Packaging'],
    region: ['All', 'APAC', 'North America', 'Europe', 'LATAM', 'China', 'Taiwan', 'Vietnam'],
    riskLevel: ['All', 'Low', 'Medium', 'High', 'Critical'],
    criticality: ['All', 'Strategic', 'Leverage', 'Bottleneck', 'Non-Critical']
  };

  return (
    <div className="flex items-center gap-4 flex-wrap">
      <div className="flex items-center gap-2 text-slate-700">
        <Filter className="w-5 h-5" />
        <span>Filters:</span>
      </div>

      {Object.entries(filterOptions).map(([key, options]) => (
        <div key={key} className="flex items-center gap-2">
          <label className="text-sm text-slate-600 capitalize">{key}:</label>
          <select
            value={filters[key]}
            onChange={(e) => setFilters({ ...filters, [key]: e.target.value })}
            className="px-3 py-2 border border-slate-300 rounded-lg bg-white text-sm hover:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {options.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>
      ))}

      <button
        onClick={() =>
          setFilters({
            supplier: 'All',
            category: 'All',
            region: 'All',
            riskLevel: 'All',
            criticality: 'All'
          })
        }
        className="ml-auto px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
      >
        Reset Filters
      </button>
    </div>
  );
}
