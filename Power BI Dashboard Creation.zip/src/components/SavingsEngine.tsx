import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, ComposedChart, Line } from 'recharts';
import { DollarSign, TrendingUp, RefreshCw, Package } from 'lucide-react';

interface SavingsEngineProps {
  filters: any;
}

export function SavingsEngine({ filters }: SavingsEngineProps) {
  // Savings Waterfall Data
  const waterfallData = [
    { name: 'Baseline Spend', value: 2800, cumulative: 2800, type: 'baseline' },
    { name: 'Negotiated Savings', value: -142, cumulative: 2658, type: 'savings' },
    { name: 'Realized Savings', value: -124, cumulative: 2534, type: 'realized' },
    { name: 'Leakage', value: 18, cumulative: 2552, type: 'leakage' },
    { name: 'Cost Avoidance', value: -68, cumulative: 2484, type: 'avoidance' },
    { name: 'Net Position', value: 2484, cumulative: 2484, type: 'final' }
  ];

  // Should-Cost Gap Analysis
  const shouldCostData = [
    { category: 'Memory Modules', current: 680, shouldCost: 612, gap: 68, opportunity: 10.0 },
    { category: 'Display Panels', current: 520, shouldCost: 478, gap: 42, opportunity: 8.1 },
    { category: 'Processors', current: 450, shouldCost: 428, gap: 22, opportunity: 4.9 },
    { category: 'PCBs', current: 280, shouldCost: 268, gap: 12, opportunity: 4.3 },
    { category: 'Plastic Housing', current: 180, shouldCost: 173, gap: 7, opportunity: 3.9 }
  ];

  // Supplier Switching Benefits
  const switchingData = [
    { supplier: 'Current: Supplier A', category: 'Memory', price: 85, quality: 94, lead: 45 },
    { supplier: 'Alt: Supplier B', category: 'Memory', price: 78, quality: 96, lead: 38, savings: 8.2 },
    { supplier: 'Current: Supplier C', category: 'Displays', price: 125, quality: 92, lead: 52 },
    { supplier: 'Alt: Supplier D', category: 'Displays', price: 118, quality: 94, lead: 48, savings: 5.6 },
    { supplier: 'Current: Supplier E', category: 'Components', price: 45, quality: 88, lead: 35 },
    { supplier: 'Alt: Supplier F', category: 'Components', price: 42, quality: 91, lead: 30, savings: 6.7 }
  ];

  // Part-Level Cost Decomposition
  const costBreakdown = [
    {
      part: 'DDR5-4800 Module',
      material: 42.3,
      labor: 8.5,
      logistics: 4.2,
      duties: 3.8,
      sga: 6.2,
      yield: 2.0,
      total: 67.0,
      current: 78.0,
      opportunity: 11.0
    },
    {
      part: '15.6" LCD Panel',
      material: 68.5,
      labor: 12.3,
      logistics: 8.4,
      duties: 6.5,
      sga: 9.8,
      yield: 4.5,
      total: 110.0,
      current: 125.0,
      opportunity: 15.0
    },
    {
      part: 'Core i7 Processor',
      material: 185.0,
      labor: 15.2,
      logistics: 6.8,
      duties: 8.2,
      sga: 12.5,
      yield: 3.3,
      total: 231.0,
      current: 245.0,
      opportunity: 14.0
    }
  ];

  const opportunities = [
    {
      icon: DollarSign,
      title: 'Should-Cost Gap',
      value: '$151M',
      description: 'Opportunity from closing should-cost variance'
    },
    {
      icon: RefreshCw,
      title: 'Supplier Switching',
      value: '$28M',
      description: 'Potential savings from alternative suppliers'
    },
    {
      icon: TrendingUp,
      title: 'Renegotiation',
      value: '$45M',
      description: 'Price improvement from contract renewal'
    },
    {
      icon: Package,
      title: 'Design Optimization',
      value: '$22M',
      description: 'Cost-out through part redesign & consolidation'
    }
  ];

  const getColor = (type: string) => {
    switch (type) {
      case 'baseline':
        return '#94a3b8';
      case 'savings':
        return '#10b981';
      case 'realized':
        return '#3b82f6';
      case 'leakage':
        return '#ef4444';
      case 'avoidance':
        return '#06b6d4';
      case 'final':
        return '#8b5cf6';
      default:
        return '#94a3b8';
    }
  };

  return (
    <div className="space-y-6">
      {/* Opportunity Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        {opportunities.map((opp, index) => {
          const Icon = opp.icon;
          return (
            <div key={index} className="bg-white p-5 rounded-lg shadow-sm border border-slate-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 rounded-lg bg-blue-100">
                  <Icon className="w-5 h-5 text-blue-600" />
                </div>
                <div className="text-2xl">{opp.value}</div>
              </div>
              <div className="text-sm mb-1">{opp.title}</div>
              <div className="text-xs text-slate-600">{opp.description}</div>
            </div>
          );
        })}
      </div>

      {/* Savings Waterfall Chart */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h3 className="mb-4">Savings Opportunity Waterfall</h3>
        <ResponsiveContainer width="100%" height={350}>
          <ComposedChart data={waterfallData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" angle={-15} textAnchor="end" height={80} />
            <YAxis label={{ value: 'Spend ($M)', angle: -90, position: 'insideLeft' }} />
            <Tooltip />
            <Bar dataKey="cumulative" fill="#8884d8">
              {waterfallData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={getColor(entry.type)} />
              ))}
            </Bar>
            <Line type="monotone" dataKey="cumulative" stroke="#1e293b" strokeWidth={2} dot={{ r: 4 }} />
          </ComposedChart>
        </ResponsiveContainer>
        <div className="mt-4 grid grid-cols-6 gap-4 text-sm">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-slate-400 rounded" />
              <span>Baseline</span>
            </div>
            <div>$2,800M</div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-green-500 rounded" />
              <span>Negotiated</span>
            </div>
            <div>-$142M</div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span>Realized</span>
            </div>
            <div>-$124M</div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-red-500 rounded" />
              <span>Leakage</span>
            </div>
            <div>+$18M</div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-cyan-500 rounded" />
              <span>Avoidance</span>
            </div>
            <div>-$68M</div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-3 h-3 bg-purple-500 rounded" />
              <span>Net Position</span>
            </div>
            <div>$2,484M</div>
          </div>
        </div>
      </div>

      {/* Should-Cost Gap Analysis */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h3 className="mb-4">Should-Cost Gap Analysis (Top Opportunities)</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={shouldCostData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="category" />
            <YAxis label={{ value: 'Cost ($M)', angle: -90, position: 'insideLeft' }} />
            <Tooltip />
            <Legend />
            <Bar dataKey="shouldCost" fill="#10b981" name="Should-Cost" />
            <Bar dataKey="current" fill="#3b82f6" name="Current Cost" />
          </BarChart>
        </ResponsiveContainer>
        <div className="mt-4">
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-2 text-left">Category</th>
                <th className="px-4 py-2 text-right">Current</th>
                <th className="px-4 py-2 text-right">Should-Cost</th>
                <th className="px-4 py-2 text-right">Gap</th>
                <th className="px-4 py-2 text-right">Opportunity %</th>
              </tr>
            </thead>
            <tbody>
              {shouldCostData.map((item, index) => (
                <tr key={index} className="border-t border-slate-200">
                  <td className="px-4 py-2">{item.category}</td>
                  <td className="px-4 py-2 text-right">${item.current}M</td>
                  <td className="px-4 py-2 text-right">${item.shouldCost}M</td>
                  <td className="px-4 py-2 text-right text-red-600">${item.gap}M</td>
                  <td className="px-4 py-2 text-right">{item.opportunity}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Part-Level Cost Decomposition */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h3 className="mb-4">Part-Level Cost Decomposition</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-2 text-left">Part Number</th>
                <th className="px-4 py-2 text-right">Material</th>
                <th className="px-4 py-2 text-right">Labor</th>
                <th className="px-4 py-2 text-right">Logistics</th>
                <th className="px-4 py-2 text-right">Duties</th>
                <th className="px-4 py-2 text-right">SG&A</th>
                <th className="px-4 py-2 text-right">Yield</th>
                <th className="px-4 py-2 text-right">Should-Cost</th>
                <th className="px-4 py-2 text-right">Current</th>
                <th className="px-4 py-2 text-right">Opportunity</th>
              </tr>
            </thead>
            <tbody>
              {costBreakdown.map((item, index) => (
                <tr key={index} className="border-t border-slate-200">
                  <td className="px-4 py-2">{item.part}</td>
                  <td className="px-4 py-2 text-right">${item.material}</td>
                  <td className="px-4 py-2 text-right">${item.labor}</td>
                  <td className="px-4 py-2 text-right">${item.logistics}</td>
                  <td className="px-4 py-2 text-right">${item.duties}</td>
                  <td className="px-4 py-2 text-right">${item.sga}</td>
                  <td className="px-4 py-2 text-right">${item.yield}</td>
                  <td className="px-4 py-2 text-right">${item.total}</td>
                  <td className="px-4 py-2 text-right">${item.current}</td>
                  <td className="px-4 py-2 text-right text-green-600">${item.opportunity}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
