import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ZAxis, ResponsiveContainer, Cell } from 'recharts';
import { Target, Zap, RefreshCw, Shield } from 'lucide-react';

interface StrategicValueProps {
  filters: any;
}

export function StrategicValue({ filters }: StrategicValueProps) {
  // Portfolio Prioritization Matrix
  const portfolioData = [
    { category: 'Memory Modules', strategicValue: 92, savingsPotential: 85, spend: 680, quadrant: 'invest' },
    { category: 'Processors', strategicValue: 95, savingsPotential: 42, spend: 450, quadrant: 'maintain' },
    { category: 'Display Panels', strategicValue: 78, savingsPotential: 78, spend: 520, quadrant: 'transform' },
    { category: 'PCBs', strategicValue: 72, savingsPotential: 55, spend: 280, quadrant: 'transform' },
    { category: 'Batteries', strategicValue: 88, savingsPotential: 38, spend: 320, quadrant: 'maintain' },
    { category: 'Plastics', strategicValue: 45, savingsPotential: 82, spend: 180, quadrant: 'harvest' },
    { category: 'Packaging', strategicValue: 38, savingsPotential: 72, spend: 120, quadrant: 'harvest' },
    { category: 'Cables', strategicValue: 42, savingsPotential: 45, spend: 90, quadrant: 'harvest' },
    { category: 'Semiconductors', strategicValue: 98, savingsPotential: 35, spend: 450, quadrant: 'maintain' },
    { category: 'Storage', strategicValue: 85, savingsPotential: 68, spend: 380, quadrant: 'invest' }
  ];

  // Category Strategy Details
  const categoryStrategies = [
    {
      category: 'Memory Modules',
      maturity: 'Mature',
      marketCondition: 'Volatile - DRAM pricing cycles',
      costDrivers: 'Material cost (silicon), Capacity utilization',
      strategy: 'Negotiate with volume commitments',
      action: 'Lock long-term pricing with floor/ceiling',
      icon: Zap,
      color: 'blue'
    },
    {
      category: 'Display Panels',
      maturity: 'Developing',
      marketCondition: 'Oversupply - pricing pressure',
      costDrivers: 'Technology transition (LCD → OLED)',
      strategy: 'Switch & consolidate suppliers',
      action: 'Qualify 2 new suppliers for OLED panels',
      icon: RefreshCw,
      color: 'purple'
    },
    {
      category: 'Plastics',
      maturity: 'Mature',
      marketCondition: 'Commodity - linked to oil prices',
      costDrivers: 'Resin cost, Tooling amortization',
      strategy: 'Automate sourcing via e-auctions',
      action: 'Implement quarterly RFQs with 5+ suppliers',
      icon: Target,
      color: 'amber'
    },
    {
      category: 'Semiconductors',
      maturity: 'Strategic',
      marketCondition: 'Supply constrained - long lead times',
      costDrivers: 'Wafer allocation, Advanced nodes',
      strategy: 'Maintain strategic partnerships',
      action: 'Secure capacity reservations with TSMC/Samsung',
      icon: Shield,
      color: 'green'
    }
  ];

  // Innovation Contribution Data
  const innovationData = [
    { supplier: 'Samsung', npiContribution: 95, patents: 24, coDevProjects: 8 },
    { supplier: 'TSMC', npiContribution: 92, patents: 18, coDevProjects: 12 },
    { supplier: 'SK Hynix', npiContribution: 88, patents: 15, coDevProjects: 6 },
    { supplier: 'Foxconn', npiContribution: 72, patents: 8, coDevProjects: 4 },
    { supplier: 'Pegatron', npiContribution: 65, patents: 5, coDevProjects: 3 },
    { supplier: 'Quanta', npiContribution: 58, patents: 4, coDevProjects: 2 }
  ];

  const getQuadrantColor = (quadrant: string) => {
    switch (quadrant) {
      case 'invest':
        return '#10b981'; // Green - high value, high savings
      case 'maintain':
        return '#3b82f6'; // Blue - high value, lower savings
      case 'transform':
        return '#f59e0b'; // Amber - medium value, high savings
      case 'harvest':
        return '#94a3b8'; // Gray - lower value
      default:
        return '#94a3b8';
    }
  };

  const getInnovationColor = (score: number) => {
    if (score >= 85) return '#10b981';
    if (score >= 70) return '#3b82f6';
    if (score >= 60) return '#f59e0b';
    return '#ef4444';
  };

  return (
    <div className="space-y-6">
      {/* Portfolio Prioritization Matrix */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h3 className="mb-4">Portfolio Prioritization Matrix (Strategic Value vs Savings Potential)</h3>
        <ResponsiveContainer width="100%" height={500}>
          <ScatterChart margin={{ top: 20, right: 80, bottom: 60, left: 60 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis
              type="number"
              dataKey="strategicValue"
              name="Strategic Value"
              domain={[30, 100]}
              label={{ value: 'Strategic Value Score →', position: 'bottom', offset: 40 }}
            />
            <YAxis
              type="number"
              dataKey="savingsPotential"
              name="Savings Potential"
              domain={[30, 90]}
              label={{ value: '← Savings Potential Score', angle: -90, position: 'insideLeft' }}
            />
            <ZAxis type="number" dataKey="spend" range={[100, 1000]} name="Spend ($M)" />
            <Tooltip
              cursor={{ strokeDasharray: '3 3' }}
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-white p-3 border border-slate-200 rounded-lg shadow-lg">
                      <p className="font-medium">{data.category}</p>
                      <p className="text-sm text-slate-600">Strategic Value: {data.strategicValue}</p>
                      <p className="text-sm text-slate-600">Savings Potential: {data.savingsPotential}</p>
                      <p className="text-sm text-slate-600">Spend: ${data.spend}M</p>
                      <p className="text-sm mt-1 capitalize">
                        <span className="font-medium">Quadrant:</span> {data.quadrant}
                      </p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Scatter name="Categories" data={portfolioData} shape="circle">
              {portfolioData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={getQuadrantColor(entry.quadrant)} />
              ))}
            </Scatter>
            {/* Quadrant Lines */}
            <line x1="65%" y1="0" x2="65%" y2="100%" stroke="#cbd5e1" strokeWidth={2} strokeDasharray="5 5" />
            <line x1="0" y1="62%" x2="100%" y2="62%" stroke="#cbd5e1" strokeWidth={2} strokeDasharray="5 5" />
          </ScatterChart>
        </ResponsiveContainer>

        {/* Quadrant Legend */}
        <div className="mt-6 grid grid-cols-4 gap-4">
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="font-medium">Invest</span>
            </div>
            <p className="text-xs text-slate-600">High value + High savings. Prioritize transformation initiatives.</p>
          </div>
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full" />
              <span className="font-medium">Maintain</span>
            </div>
            <p className="text-xs text-slate-600">High value + Lower savings. Secure supply & maintain relationships.</p>
          </div>
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 bg-amber-500 rounded-full" />
              <span className="font-medium">Transform</span>
            </div>
            <p className="text-xs text-slate-600">Medium value + High savings. Aggressive cost reduction.</p>
          </div>
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 bg-slate-400 rounded-full" />
              <span className="font-medium">Harvest</span>
            </div>
            <p className="text-xs text-slate-600">Lower value. Automate, standardize, or consider outsourcing.</p>
          </div>
        </div>
      </div>

      {/* Category Strategy Cards */}
      <div>
        <h3 className="mb-4">Category Sourcing Strategy</h3>
        <div className="grid grid-cols-2 gap-4">
          {categoryStrategies.map((strategy, index) => {
            const Icon = strategy.icon;
            return (
              <div key={index} className="bg-white p-5 rounded-lg shadow-sm border border-slate-200">
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-lg bg-${strategy.color}-100`}>
                    <Icon className={`w-6 h-6 text-${strategy.color}-600`} />
                  </div>
                  <div className="flex-1">
                    <h4 className="mb-3">{strategy.category}</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex">
                        <span className="w-32 text-slate-600">Maturity:</span>
                        <span>{strategy.maturity}</span>
                      </div>
                      <div className="flex">
                        <span className="w-32 text-slate-600">Market:</span>
                        <span>{strategy.marketCondition}</span>
                      </div>
                      <div className="flex">
                        <span className="w-32 text-slate-600">Cost Drivers:</span>
                        <span>{strategy.costDrivers}</span>
                      </div>
                      <div className="flex">
                        <span className="w-32 text-slate-600">Strategy:</span>
                        <span className="font-medium text-blue-600">{strategy.strategy}</span>
                      </div>
                      <div className="flex">
                        <span className="w-32 text-slate-600">Next Action:</span>
                        <span className="text-green-600">{strategy.action}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Innovation Contribution Heatmap */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h3 className="mb-4">Supplier Innovation Contribution (NPI Support)</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-left">Supplier</th>
                <th className="px-4 py-3 text-center">NPI Contribution Score</th>
                <th className="px-4 py-3 text-center">Patents Filed (Joint)</th>
                <th className="px-4 py-3 text-center">Co-Dev Projects</th>
                <th className="px-4 py-3 text-center">Innovation Level</th>
              </tr>
            </thead>
            <tbody>
              {innovationData.map((item, index) => (
                <tr key={index} className="border-t border-slate-200">
                  <td className="px-4 py-3">{item.supplier}</td>
                  <td className="px-4 py-3 text-center">
                    <div
                      className="inline-flex items-center justify-center w-16 h-8 rounded"
                      style={{ backgroundColor: getInnovationColor(item.npiContribution) + '20', color: getInnovationColor(item.npiContribution) }}
                    >
                      {item.npiContribution}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-center">{item.patents}</td>
                  <td className="px-4 py-3 text-center">{item.coDevProjects}</td>
                  <td className="px-4 py-3 text-center">
                    {item.npiContribution >= 85 && (
                      <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs">
                        Strategic Partner
                      </span>
                    )}
                    {item.npiContribution >= 70 && item.npiContribution < 85 && (
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                        Collaborative
                      </span>
                    )}
                    {item.npiContribution >= 60 && item.npiContribution < 70 && (
                      <span className="px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-xs">
                        Standard
                      </span>
                    )}
                    {item.npiContribution < 60 && (
                      <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-xs">
                        Transactional
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm">
            <span className="font-medium">Strategic Insight:</span> Samsung and TSMC provide highest innovation
            contribution with 95+ NPI scores. Maintain strategic partnership status and prioritize early supplier
            involvement in next-gen product development.
          </p>
        </div>
      </div>
    </div>
  );
}
