import { TrendingUp, TrendingDown, DollarSign, Shield, Globe, Award, AlertTriangle, Target } from 'lucide-react';

interface KPIRibbonProps {
  filters: any;
}

export function KPIRibbon({ filters }: KPIRibbonProps) {
  const kpis = [
    {
      label: 'Total Spend (YTD)',
      value: '$2.8B',
      target: '$2.9B',
      trend: 'down',
      change: '-3.4%',
      status: 'good',
      icon: DollarSign,
      color: 'blue'
    },
    {
      label: 'Negotiated Savings',
      value: '$142M',
      target: '$120M',
      trend: 'up',
      change: '+18.3%',
      status: 'excellent',
      icon: TrendingUp,
      color: 'green'
    },
    {
      label: 'Realized Savings',
      value: '$124M',
      target: '$142M',
      trend: 'up',
      change: '87.3%',
      status: 'good',
      icon: Target,
      color: 'emerald'
    },
    {
      label: 'Cost Avoidance',
      value: '$68M',
      target: '$50M',
      trend: 'up',
      change: '+36%',
      status: 'excellent',
      icon: Shield,
      color: 'cyan'
    },
    {
      label: 'Should-Cost Variance',
      value: '8.2%',
      target: '<10%',
      trend: 'down',
      change: '-1.8%',
      status: 'good',
      icon: TrendingDown,
      color: 'blue'
    },
    {
      label: 'Supplier Risk Score',
      value: '34',
      target: '<40',
      trend: 'down',
      change: '-6 pts',
      status: 'good',
      icon: AlertTriangle,
      color: 'amber'
    },
    {
      label: 'Supplier Resiliency',
      value: '78',
      target: '>75',
      trend: 'up',
      change: '+4 pts',
      status: 'excellent',
      icon: Shield,
      color: 'green'
    },
    {
      label: 'Supplier Performance',
      value: '94.2%',
      target: '>90%',
      trend: 'up',
      change: '+2.1%',
      status: 'excellent',
      icon: Award,
      color: 'green'
    },
    {
      label: 'Supply Continuity Risk',
      value: '12 days',
      target: '<15',
      trend: 'down',
      change: '-3 days',
      status: 'good',
      icon: Globe,
      color: 'cyan'
    },
    {
      label: 'Strategic Value Score',
      value: '82',
      target: '>75',
      trend: 'up',
      change: '+7 pts',
      status: 'excellent',
      icon: Target,
      color: 'blue'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent':
        return 'border-green-500 bg-green-50';
      case 'good':
        return 'border-blue-500 bg-blue-50';
      case 'warning':
        return 'border-amber-500 bg-amber-50';
      case 'critical':
        return 'border-red-500 bg-red-50';
      default:
        return 'border-slate-300 bg-white';
    }
  };

  return (
    <div className="p-6">
      <div className="grid grid-cols-5 gap-4">
        {kpis.map((kpi, index) => {
          const Icon = kpi.icon;
          const TrendIcon = kpi.trend === 'up' ? TrendingUp : TrendingDown;
          const trendColor = kpi.status === 'excellent' || kpi.status === 'good' 
            ? 'text-green-600' 
            : 'text-red-600';

          return (
            <div
              key={index}
              className={`p-4 rounded-lg border-l-4 shadow-sm transition-all hover:shadow-md ${getStatusColor(kpi.status)}`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className={`p-2 rounded-lg bg-${kpi.color}-100`}>
                  <Icon className={`w-5 h-5 text-${kpi.color}-600`} />
                </div>
                <div className={`flex items-center gap-1 text-sm ${trendColor}`}>
                  <TrendIcon className="w-4 h-4" />
                  <span>{kpi.change}</span>
                </div>
              </div>
              <div className="text-2xl mb-1">{kpi.value}</div>
              <div className="text-sm text-slate-600 mb-1">{kpi.label}</div>
              <div className="text-xs text-slate-500">Target: {kpi.target}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
