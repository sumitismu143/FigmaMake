import { useState } from 'react';
import { Send, Sparkles, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, BarChart3, PieChart, LineChart } from 'lucide-react';
import { BarChart, Bar, LineChart as RechartsLineChart, Line, PieChart as RechartsPieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  visualization?: 'bar' | 'line' | 'pie' | 'none';
  data?: any[];
  insights?: string[];
}

interface GenieAssistantProps {
  filters: any;
}

export function GenieAssistant({ filters }: GenieAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: 'Hello! I\'m HP Genie, your AI-powered procurement intelligence assistant. Ask me anything about your sourcing data, suppliers, cost savings opportunities, or strategic insights.',
      timestamp: new Date(),
      visualization: 'none'
    }
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const sampleQuestions = [
    'Which suppliers have the highest risk scores?',
    'Show me cost savings opportunities by category',
    'What are the top spending categories this quarter?',
    'Analyze supplier performance trends over time',
    'Identify suppliers suitable for reshoring',
    'Compare regional spend distribution'
  ];

  const COLORS = ['#0369a1', '#0284c7', '#0ea5e9', '#38bdf8', '#7dd3fc', '#bae6fd'];

  // Mock data generators based on query type
  const generateSupplierRiskData = () => [
    { name: 'GlobalTech Asia', riskScore: 85, category: 'Semiconductors' },
    { name: 'ChipCorp Taiwan', riskScore: 72, category: 'IC Components' },
    { name: 'EuroComponents', riskScore: 68, category: 'PCBs' },
    { name: 'MexicoAssembly', riskScore: 45, category: 'Assembly' },
    { name: 'USALogistics', riskScore: 28, category: 'Logistics' }
  ];

  const generateSavingsData = () => [
    { category: 'Semiconductors', potential: 2.8, realized: 1.2 },
    { category: 'PCBs', potential: 1.5, realized: 0.9 },
    { category: 'Connectors', potential: 0.8, realized: 0.6 },
    { category: 'Assembly', potential: 1.2, realized: 0.4 },
    { category: 'Logistics', potential: 0.6, realized: 0.3 }
  ];

  const generateSpendData = () => [
    { name: 'Semiconductors', value: 145.2 },
    { name: 'PCBs', value: 67.8 },
    { name: 'Connectors', value: 34.5 },
    { name: 'Assembly', value: 89.3 },
    { name: 'Packaging', value: 23.4 }
  ];

  const generatePerformanceTrend = () => [
    { month: 'Jan', score: 72 },
    { month: 'Feb', score: 75 },
    { month: 'Mar', score: 73 },
    { month: 'Apr', score: 78 },
    { month: 'May', score: 82 },
    { month: 'Jun', score: 85 }
  ];

  const generateReshoringData = () => [
    { name: 'GlobalTech Asia', score: 78, reason: 'High automation capability' },
    { name: 'ChipCorp Taiwan', score: 65, reason: 'Quality track record' },
    { name: 'EuroComponents', score: 58, reason: 'Moderate complexity' },
    { name: 'MexicoAssembly', score: 45, reason: 'Labor dependent' },
    { name: 'AsiaPackaging', score: 32, reason: 'Low value add' }
  ];

  const generateRegionalSpend = () => [
    { name: 'Asia Pacific', value: 187.5 },
    { name: 'North America', value: 98.3 },
    { name: 'Europe', value: 76.4 },
    { name: 'Latin America', value: 45.6 }
  ];

  // AI Response Generator
  const generateAIResponse = (query: string): Message => {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('risk') && lowerQuery.includes('supplier')) {
      return {
        id: Date.now().toString(),
        type: 'assistant',
        content: 'I\'ve analyzed supplier risk scores across your portfolio. Here\'s what I found:',
        timestamp: new Date(),
        visualization: 'bar',
        data: generateSupplierRiskData(),
        insights: [
          'GlobalTech Asia shows highest risk (85/100) due to geographic concentration and geopolitical factors',
          'ChipCorp Taiwan has elevated risk (72/100) from single-source dependency',
          'USA-based suppliers show significantly lower risk profiles',
          'Recommendation: Develop dual-sourcing strategy for top 2 high-risk suppliers'
        ]
      };
    }
    
    if (lowerQuery.includes('savings') || lowerQuery.includes('cost')) {
      return {
        id: Date.now().toString(),
        type: 'assistant',
        content: 'Here\'s the cost savings analysis by category with potential vs. realized savings:',
        timestamp: new Date(),
        visualization: 'bar',
        data: generateSavingsData(),
        insights: [
          'Total savings potential identified: $6.9M across all categories',
          'Current realization rate: 48% with $3.4M captured',
          'Semiconductors offer largest opportunity: $2.8M potential with only 43% captured',
          'PCBs show strong execution: 60% realization rate',
          'Recommendation: Focus on semiconductor negotiations and contract optimization'
        ]
      };
    }
    
    if (lowerQuery.includes('spending') || lowerQuery.includes('spend') || lowerQuery.includes('categories')) {
      return {
        id: Date.now().toString(),
        type: 'assistant',
        content: 'Here\'s your spend distribution by category for the current quarter:',
        timestamp: new Date(),
        visualization: 'pie',
        data: generateSpendData(),
        insights: [
          'Total quarterly spend: $360.2M across 5 major categories',
          'Semiconductors dominate at 40.3% ($145.2M) of total spend',
          'Assembly operations represent 24.8% ($89.3M)',
          'PCBs and Connectors combined: $102.3M (28.4%)',
          'Recommendation: Consolidate packaging suppliers to improve leverage'
        ]
      };
    }
    
    if (lowerQuery.includes('performance') || lowerQuery.includes('trend')) {
      return {
        id: Date.now().toString(),
        type: 'assistant',
        content: 'Supplier performance has shown positive momentum over the past 6 months:',
        timestamp: new Date(),
        visualization: 'line',
        data: generatePerformanceTrend(),
        insights: [
          'Overall supplier score improved from 72 to 85 (+18% improvement)',
          'Consistent upward trend with only minor dip in March',
          'Quality metrics driving improvement (defect rates down 34%)',
          'Delivery performance remains stable at 94% on-time',
          'Recommendation: Recognize top performers and share best practices'
        ]
      };
    }
    
    if (lowerQuery.includes('reshoring') || lowerQuery.includes('nearshoring')) {
      return {
        id: Date.now().toString(),
        type: 'assistant',
        content: 'I\'ve evaluated suppliers for reshoring feasibility based on automation potential, quality, and complexity:',
        timestamp: new Date(),
        visualization: 'bar',
        data: generateReshoringData(),
        insights: [
          'GlobalTech Asia scores highest (78/100) for reshoring viability',
          'High automation capability enables cost-competitive domestic production',
          'ChipCorp Taiwan operations moderately suitable (65/100)',
          'Labor-intensive operations show lower reshoring scores',
          'Recommendation: Pilot reshoring for automated semiconductor testing first'
        ]
      };
    }
    
    if (lowerQuery.includes('regional') || lowerQuery.includes('region')) {
      return {
        id: Date.now().toString(),
        type: 'assistant',
        content: 'Regional spend analysis shows the following distribution:',
        timestamp: new Date(),
        visualization: 'pie',
        data: generateRegionalSpend(),
        insights: [
          'Asia Pacific dominates with 46% of total spend ($187.5M)',
          'North America accounts for 24% ($98.3M)',
          'Europe represents 19% ($76.4M) with strong quality suppliers',
          'Latin America at 11% ($45.6M) growing for nearshoring',
          'Recommendation: Increase Latin America sourcing to 18% for supply chain resilience'
        ]
      };
    }
    
    // Default response
    return {
      id: Date.now().toString(),
      type: 'assistant',
      content: 'I can help you analyze various aspects of your sourcing data. Try asking about supplier risks, cost savings, spending patterns, performance trends, reshoring opportunities, or regional distribution. You can also click on the sample questions above.',
      timestamp: new Date(),
      visualization: 'none',
      insights: [
        'Ask about specific suppliers, categories, or regions',
        'Request trend analysis over time periods',
        'Inquire about risk assessments and mitigation strategies',
        'Explore cost optimization opportunities'
      ]
    };
  };

  const handleSendMessage = () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date(),
      visualization: 'none'
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsProcessing(true);

    // Simulate AI processing
    setTimeout(() => {
      const aiResponse = generateAIResponse(input);
      setMessages(prev => [...prev, aiResponse]);
      setIsProcessing(false);
    }, 1500);
  };

  const handleSampleQuestion = (question: string) => {
    setInput(question);
  };

  const renderVisualization = (message: Message) => {
    if (!message.visualization || message.visualization === 'none' || !message.data) return null;

    if (message.visualization === 'bar') {
      // Determine if it's risk, savings, or reshoring data
      const hasRiskScore = message.data[0]?.riskScore !== undefined;
      const hasPotential = message.data[0]?.potential !== undefined;
      const hasScore = message.data[0]?.score !== undefined && !hasRiskScore;

      return (
        <div className="mt-4 p-4 bg-slate-50 rounded-lg">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={message.data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px' }}
              />
              <Legend />
              {hasRiskScore && (
                <Bar dataKey="riskScore" fill="#0369a1" name="Risk Score" />
              )}
              {hasPotential && (
                <>
                  <Bar dataKey="potential" fill="#0369a1" name="Potential Savings ($M)" />
                  <Bar dataKey="realized" fill="#38bdf8" name="Realized Savings ($M)" />
                </>
              )}
              {hasScore && (
                <Bar dataKey="score" fill="#0369a1" name="Reshoring Score" />
              )}
              {!hasRiskScore && !hasPotential && !hasScore && (
                <Bar dataKey="value" fill="#0369a1" name="Value" />
              )}
            </BarChart>
          </ResponsiveContainer>
        </div>
      );
    }

    if (message.visualization === 'line') {
      return (
        <div className="mt-4 p-4 bg-slate-50 rounded-lg">
          <ResponsiveContainer width="100%" height={300}>
            <RechartsLineChart data={message.data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px' }}
              />
              <Legend />
              <Line type="monotone" dataKey="score" stroke="#0369a1" strokeWidth={2} name="Performance Score" />
            </RechartsLineChart>
          </ResponsiveContainer>
        </div>
      );
    }

    if (message.visualization === 'pie') {
      return (
        <div className="mt-4 p-4 bg-slate-50 rounded-lg">
          <ResponsiveContainer width="100%" height={300}>
            <RechartsPieChart>
              <Pie
                data={message.data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {message.data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px' }}
                formatter={(value: any) => `$${value}M`}
              />
            </RechartsPieChart>
          </ResponsiveContainer>
        </div>
      );
    }

    return null;
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 rounded-lg mb-6 shadow-lg">
        <div className="flex items-center gap-3 mb-2">
          <Sparkles className="w-8 h-8" />
          <h2 className="text-2xl">HP Genie AI Assistant</h2>
        </div>
        <p className="text-blue-100">
          Ask natural language questions about your sourcing data and get instant AI-powered insights with visualizations
        </p>
      </div>

      {/* Sample Questions */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6 mb-6">
        <h3 className="text-slate-700 mb-4 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-blue-600" />
          Sample Questions
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {sampleQuestions.map((question, index) => (
            <button
              key={index}
              onClick={() => handleSampleQuestion(question)}
              className="text-left p-3 rounded-lg border border-slate-200 hover:border-blue-400 hover:bg-blue-50 transition-colors text-sm text-slate-700"
            >
              {question}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Container */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 mb-6">
        {/* Messages */}
        <div className="h-[600px] overflow-y-auto p-6 space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-4 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.type === 'assistant' && (
                <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
              )}
              
              <div className={`flex-1 max-w-3xl ${message.type === 'user' ? 'flex justify-end' : ''}`}>
                <div
                  className={`rounded-lg p-4 ${
                    message.type === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-50 text-slate-900'
                  }`}
                >
                  <p className="mb-1">{message.content}</p>
                  
                  {/* Visualization */}
                  {renderVisualization(message)}
                  
                  {/* Insights */}
                  {message.insights && message.insights.length > 0 && (
                    <div className="mt-4 space-y-2">
                      <p className="text-sm opacity-90">
                        <strong>Key Insights:</strong>
                      </p>
                      {message.insights.map((insight, index) => (
                        <div key={index} className="flex items-start gap-2 text-sm">
                          {insight.toLowerCase().includes('recommendation') ? (
                            <AlertTriangle className="w-4 h-4 mt-0.5 text-amber-500 flex-shrink-0" />
                          ) : (
                            <CheckCircle className="w-4 h-4 mt-0.5 text-blue-600 flex-shrink-0" />
                          )}
                          <span className="opacity-90">{insight}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <p className="text-xs opacity-60 mt-2">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>

              {message.type === 'user' && (
                <div className="flex-shrink-0 w-10 h-10 bg-slate-300 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">You</span>
                </div>
              )}
            </div>
          ))}
          
          {isProcessing && (
            <div className="flex gap-4 justify-start">
              <div className="flex-shrink-0 w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white animate-pulse" />
              </div>
              <div className="flex-1 max-w-3xl">
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="border-t border-slate-200 p-4">
          <div className="flex gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask anything about your sourcing data..."
              className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={isProcessing}
            />
            <button
              onClick={handleSendMessage}
              disabled={isProcessing || !input.trim()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              Send
            </button>
          </div>
        </div>
      </div>

      {/* Stats Footer */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-slate-600">Queries Processed</p>
              <p className="text-xl text-slate-900">{messages.filter(m => m.type === 'user').length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-xs text-slate-600">Insights Generated</p>
              <p className="text-xl text-slate-900">
                {messages.reduce((sum, m) => sum + (m.insights?.length || 0), 0)}
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <PieChart className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-xs text-slate-600">Visualizations</p>
              <p className="text-xl text-slate-900">
                {messages.filter(m => m.visualization && m.visualization !== 'none').length}
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-xs text-slate-600">Recommendations</p>
              <p className="text-xl text-slate-900">
                {messages.reduce((sum, m) => 
                  sum + (m.insights?.filter(i => i.toLowerCase().includes('recommendation')).length || 0), 0
                )}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
