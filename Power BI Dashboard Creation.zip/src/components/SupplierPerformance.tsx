import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ZAxis, ResponsiveContainer, Cell } from 'recharts';
import { Award, TrendingUp, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface SupplierPerformanceProps {
  filters: any;
}

export function SupplierPerformance({ filters }: SupplierPerformanceProps) {
  // Supplier Scorecard Data
  const topSuppliers = [
    {
      name: 'Foxconn',
      otd: 96.5,
      qualityPpm: 145,
      costCompetitive: 92,
      esg: 85,
      financial: 88,
      capacity: 94,
      overall: 93
    },
    {
      name: 'Samsung',
      otd: 98.2,
      qualityPpm: 88,
      costCompetitive: 88,
      esg: 92,
      financial: 95,
      capacity: 91,
      overall: 95
    },
    {
      name: 'Pegatron',
      otd: 94.8,
      qualityPpm: 210,
      costCompetitive: 90,
      esg: 82,
      financial: 86,
      capacity: 89,
      overall: 90
    },
    {
      name: 'SK Hynix',
      otd: 97.5,
      qualityPpm: 95,
      costCompetitive: 86,
      esg: 90,
      financial: 93,
      capacity: 88,
      overall: 94
    }
  ];

  // Risk Radar Data
  const riskRadarData = [
    { risk: 'Geo Risk', foxconn: 65, samsung: 35, pegatron: 70 },
    { risk: 'Financial', foxconn: 15, samsung: 10, pegatron: 18 },
    { risk: 'Quality', foxconn: 25, samsung: 15, pegatron: 35 },
    { risk: 'Lead Time', foxconn: 30, samsung: 20, pegatron: 40 },
    { risk: 'ESG', foxconn: 20, samsung: 12, pegatron: 25 },
    { risk: 'Capacity', foxconn: 18, samsung: 15, pegatron: 22 }
  ];

  // Supplier Resiliency Matrix (2x2)
  const resiliencyData = [
    { name: 'Foxconn', performance: 93, risk: 35, spend: 580 },
    { name: 'Samsung', performance: 95, risk: 20, spend: 380 },
    { name: 'Pegatron', performance: 90, risk: 42, spend: 420 },
    { name: 'SK Hynix', performance: 94, risk: 22, spend: 340 },
    { name: 'Quanta', performance: 88, risk: 38, spend: 280 },
    { name: 'TSMC', performance: 96, risk: 18, spend: 260 },
    { name: 'Compal', performance: 86, risk: 45, spend: 220 },
    { name: 'Wistron', performance: 89, risk: 32, spend: 180 }
  ];

  // Early Warning Signals
  const warnings = [
    {
      supplier: 'Pegatron',
      signal: 'Quality PPM Rising',
      metric: '210 ppm (↑ 15%)',
      severity: 'medium',
      icon: AlertTriangle
    },
    {
      supplier: 'Quanta',
      signal: 'Lead Time Increase',
      metric: '52 days (↑ 8 days)',
      severity: 'medium',
      icon: TrendingUp
    },
    {
      supplier: 'Compal',
      signal: 'Capacity Constraint',
      metric: '78% utilization',
      severity: 'high',
      icon: XCircle
    },
    {
      supplier: 'Wistron',
      signal: 'ESG Rating Drop',
      metric: 'Score: 76 (↓ 5 pts)',
      severity: 'low',
      icon: AlertTriangle
    }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'border-red-500 bg-red-50';
      case 'medium':
        return 'border-amber-500 bg-amber-50';
      case 'low':
        return 'border-yellow-500 bg-yellow-50';
      default:
        return 'border-slate-300 bg-slate-50';
    }
  };

  const getScatterColor = (risk: number) => {
    if (risk < 25) return '#10b981'; // Low risk - green
    if (risk < 40) return '#f59e0b'; // Medium risk - amber
    return '#ef4444'; // High risk - red
  };

  return (
    <div className="space-y-6">
      {/* Early Warning Signals */}
      <div>
        <h3 className="mb-4">Early Warning Signals</h3>
        <div className="grid grid-cols-4 gap-4">
          {warnings.map((warning, index) => {
            const Icon = warning.icon;
            return (
              <div
                key={index}
                className={`p-4 rounded-lg border-l-4 shadow-sm ${getSeverityColor(warning.severity)}`}
              >
                <div className="flex items-start gap-3">
                  <Icon className="w-5 h-5 text-amber-600 mt-1" />
                  <div className="flex-1">
                    <div className="text-sm mb-1">{warning.supplier}</div>
                    <div className="text-xs text-slate-600 mb-2">{warning.signal}</div>
                    <div className="text-sm">{warning.metric}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Supplier Scorecard */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h3 className="mb-4">Top Supplier Scorecard</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-left">Supplier</th>
                <th className="px-4 py-3 text-center">On-Time Delivery</th>
                <th className="px-4 py-3 text-center">Quality (PPM)</th>
                <th className="px-4 py-3 text-center">Cost Competitive</th>
                <th className="px-4 py-3 text-center">ESG Score</th>
                <th className="px-4 py-3 text-center">Financial Stability</th>
                <th className="px-4 py-3 text-center">Capacity</th>
                <th className="px-4 py-3 text-center">Overall</th>
              </tr>
            </thead>
            <tbody>
              {topSuppliers.map((supplier, index) => (
                <tr key={index} className="border-t border-slate-200 hover:bg-slate-50">
                  <td className="px-4 py-3">{supplier.name}</td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center gap-2">
                      {supplier.otd >= 95 ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-600" />
                      )}
                      <span>{supplier.otd}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={supplier.qualityPpm < 150 ? 'text-green-600' : 'text-amber-600'}>
                      {supplier.qualityPpm}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">{supplier.costCompetitive}%</td>
                  <td className="px-4 py-3 text-center">{supplier.esg}</td>
                  <td className="px-4 py-3 text-center">{supplier.financial}</td>
                  <td className="px-4 py-3 text-center">{supplier.capacity}%</td>
                  <td className="px-4 py-3 text-center">
                    <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-blue-100 text-blue-700">
                      <Award className="w-3 h-3" />
                      <span>{supplier.overall}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Supplier Risk Radar */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="mb-4">Supplier Risk Radar (Lower is Better)</h3>
          <ResponsiveContainer width="100%" height={400}>
            <RadarChart data={riskRadarData}>
              <PolarGrid />
              <PolarAngleAxis dataKey="risk" />
              <PolarRadiusAxis angle={90} domain={[0, 100]} />
              <Radar name="Foxconn" dataKey="foxconn" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} />
              <Radar name="Samsung" dataKey="samsung" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
              <Radar name="Pegatron" dataKey="pegatron" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.3} />
              <Legend />
              <Tooltip />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Supplier Resiliency Matrix */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
          <h3 className="mb-4">Supplier Resiliency Matrix</h3>
          <ResponsiveContainer width="100%" height={400}>
            <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
              <CartesianGrid />
              <XAxis
                type="number"
                dataKey="performance"
                name="Performance"
                domain={[80, 100]}
                label={{ value: 'Performance Score →', position: 'bottom' }}
              />
              <YAxis
                type="number"
                dataKey="risk"
                name="Risk"
                domain={[0, 50]}
                label={{ value: '← Risk Score', angle: -90, position: 'insideLeft' }}
              />
              <ZAxis type="number" dataKey="spend" range={[100, 1000]} name="Spend ($M)" />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter name="Suppliers" data={resiliencyData} shape="circle">
                {resiliencyData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getScatterColor(entry.risk)} />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            <div className="flex items-center justify-between text-sm px-4 py-2 bg-slate-50 rounded">
              <span>Quadrant Logic:</span>
              <span className="text-slate-600">High Performance + Low Risk = Preferred</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full" />
                <span>Low Risk (&lt;25)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-amber-500 rounded-full" />
                <span>Medium Risk (25-40)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded-full" />
                <span>High Risk (&gt;40)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}