
  # Power BI Dashboard Creation

  This is a code bundle for Power BI Dashboard Creation. The original project is available at https://www.figma.com/design/pkwWPxj4ulEa7VAcWDRcHm/Power-BI-Dashboard-Creation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  